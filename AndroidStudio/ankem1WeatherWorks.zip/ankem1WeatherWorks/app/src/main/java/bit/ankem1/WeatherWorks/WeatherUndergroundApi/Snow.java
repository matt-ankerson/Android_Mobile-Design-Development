package bit.ankem1.WeatherWorks.WeatherUndergroundApi;

/**
 * Created by matt on 21/05/15.
 */
// This class represents a Snow JSON object returned from WeatherUnderground
public class Snow
{
    private double in;
    private double cm;

    public Snow()
    {

    }

    public double getIn()
    {
        return in;
    }
    public double getCm()
    {
        return cm;
    }
}
