package bit.ankem1.WeatherWorks.OpenWeatherMapApi;

/**
 * Created by matt on 15/05/15.
 */
// This class represents a coordinate location
public class Coord
{
    private double lon;
    private double lat;

    public Coord() {

    }

    public double getLon()
    {
        return lon;
    }

    public double getLat()
    {
        return lat;
    }
}
